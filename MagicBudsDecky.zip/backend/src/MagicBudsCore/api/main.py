import logging
logging.getLogger("magicbuds").info("HEllloooooo")