#!/bin/sh
set -e
mkdir -p /backend/out
cp /app/MagicBudsCore/api /backend/out

#python3 /backend/out/main.py